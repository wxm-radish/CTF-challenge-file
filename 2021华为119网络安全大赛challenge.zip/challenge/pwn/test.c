#include<stdio.h>
#include<stdlib.h>
int main()
{
    char *heap[0x10];
    for(int i;i<0x10;i++)
    {
        heap[i]=malloc(0x10);
    }
    for(int i;i<10;i++)
    {
        free(heap[i]);//=malloc(0x10);
    }
    return 0;
}